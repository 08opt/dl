#ifndef _PUD_UPLINKGATEWAY_H_
#define _PUD_UPLINKGATEWAY_H_

/* Plugin includes */

/* OLSRD includes */
#include "olsr_types.h"

/* System includes */

void getBestUplinkGateway(union olsr_ip_addr * bestGateway);

#endif /* _PUD_UPLINKGATEWAY_H_ */
