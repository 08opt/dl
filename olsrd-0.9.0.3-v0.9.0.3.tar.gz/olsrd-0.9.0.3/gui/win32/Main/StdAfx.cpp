#ifdef _WIN32

#include "stdafx.h"

#endif /* _WIN32 */
