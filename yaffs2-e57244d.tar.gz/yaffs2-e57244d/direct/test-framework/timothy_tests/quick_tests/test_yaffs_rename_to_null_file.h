#ifndef __test_yaffs_rename_NULL3_h__
#define __test_yaffs_rename_NULL3_h__

#include "lib.h"
#include "yaffsfs.h"

int test_yaffs_rename_to_null_file(void);
int test_yaffs_rename_to_null_file_clean(void);

#endif

