is_yaffs_working_tests folder contains the very simple tests to check that yaffs has been installed properly.

test_1_yaffs_mount.c mounts yaffs, creates a file, unmounts and then mounts yaffs and checks that the file is still there. 



compile command: make
run command: ./test_1_yaffs_mount

command line options:
	No commands.
