Run the emulation with:

 qemu-system-microblaze -M petalogix-s3adsp1800 -kernel output/images/linux.bin -serial stdio

The login prompt will appear in the terminal that started Qemu.

Tested with QEMU 2.3.0
