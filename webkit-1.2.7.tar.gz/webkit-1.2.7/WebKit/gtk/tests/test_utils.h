#include <glib.h>

int testutils_relative_chdir(const gchar*, const gchar*);
