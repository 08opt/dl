This file exists in order to create the "subdir-b" subdirectory.  There is
exists sibling directory "subdir" that is a prefix of this subdirectory.
This file exists for self-testing.
